from odoo import models, fields, api

class BarcodeWizard(models.TransientModel):
    _name = 'barcode.wizard'
    _description = 'Barcode Wizard'

    barcode = fields.Char(string='Barcode')
    product_id = fields.Many2one('product.product', string='Product')
    counted_quantity = fields.Float(string='Counted Quantity', default=1.0)
    product_not_found = fields.Boolean(string="Product Not Found", default=False)
    product_show = fields.Many2one('product.product', string='Product', readonly=True)

    @api.onchange('barcode')
    def _onchange_barcode(self):
        if self.barcode:
            product = self.env['product.product'].search([('barcode', '=', self.barcode)], limit=1)
            if product:
                self.product_id = product.id
                self.product_show = product.id
                self.product_not_found = False
            else:
                self.product_id = False
                self.product_not_found = True

    def action_add_product(self):
        active_id = self.env.context.get('active_id')
        stock_count = self.env['stock.count'].browse(active_id)

        # ตรวจสอบว่ามีสินค้านี้อยู่ใน stock count line แล้วหรือไม่
        existing_line = self.env['stock.count.line'].search([
            ('stock_count_id', '=', stock_count.id),
            ('product_id', '=', self.product_id.id)
        ], limit=1)

        if existing_line:
            # ถ้ามีบรรทัดสินค้านี้อยู่แล้ว ให้อัปเดตจำนวนที่นับเพิ่ม
            existing_line.counted_quantity += self.counted_quantity
        else:
            # ถ้าไม่มี ให้สร้างบรรทัดใหม่
            line_data = {
                'stock_count_id': stock_count.id,
                'product_id': self.product_id.id,
                'counted_quantity': self.counted_quantity,
            }
            self.env['stock.count.line'].create(line_data)

    # def action_add_and_scan(self):
    #     # ตรวจสอบว่าฟิลด์ barcode มีค่าหรือไม่
    #     if not self.barcode:
    #         raise UserError("Please scan or input a barcode before adding.")
    #
    #     # เรียกใช้ฟังก์ชันเพื่อเพิ่มสินค้า
    #     self.action_add_product()
    #
    #     # ล้างค่าฟิลด์เพื่อตรวจบาร์โค้ดถัดไปโดยไม่ปิด wizard
    #     self.barcode = False
    #     self.product_id = False
    #     self.counted_quantity = 1.0
    #     self.product_not_found = False
    #
    #     return {
    #         'type': 'ir.actions.act_window',
    #         'res_model': 'barcode.wizard',
    #         'view_mode': 'form',
    #         'target': 'new',
    #         'context': self.env.context,
    #     }
